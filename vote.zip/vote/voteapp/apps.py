from django.apps import AppConfig


class VoteappConfig(AppConfig):
    name = 'voteapp'
